
document.addEventListener("DOMContentLoaded", () => {
  loadSubjects();
});

function createSubject() {
  const subject = prompt("Nom de la matière ?");
  if (subject) {
    const ul = document.getElementById("subject-list");
    const li = document.createElement("li");
    li.textContent = subject;
    li.onclick = () => showFlashcardsFor(subject);
    ul.appendChild(li);
    addProgressBar(subject);
    saveSubject(subject);
  }
}

function addProgressBar(subject) {
  const container = document.getElementById("progress-container");
  const title = document.createElement("div");
  title.textContent = subject;
  const bar = document.createElement("div");
  bar.className = "progress-bar";
  const fill = document.createElement("div");
  fill.className = "progress-bar-fill";
  fill.id = `progress-${subject}`;
  bar.appendChild(fill);
  container.appendChild(title);
  container.appendChild(bar);
}

function showFlashcardsFor(subject) {
  const container = document.getElementById("flashcards-container");
  container.innerHTML = '';
  for (let i = 1; i <= 3; i++) {
    const card = document.createElement("div");
    card.className = "flashcard";
    card.onclick = () => card.classList.toggle("flipped");
    card.innerHTML = `<div class="front">${subject} - Question ${i}</div><div class="back">Réponse ${i}</div>`;
    container.appendChild(card);
  }
  updateProgress(subject, Math.floor(Math.random() * 100));
}

function updateProgress(subject, percent) {
  const fill = document.getElementById(`progress-${subject}`);
  if (fill) {
    fill.style.width = percent + "%";
  }
}

function saveSubject(subject) {
  const saved = JSON.parse(localStorage.getItem("subjects") || "[]");
  if (!saved.includes(subject)) {
    saved.push(subject);
    localStorage.setItem("subjects", JSON.stringify(saved));
  }
}

function loadSubjects() {
  const saved = JSON.parse(localStorage.getItem("subjects") || "[]");
  for (const subject of saved) {
    const ul = document.getElementById("subject-list");
    const li = document.createElement("li");
    li.textContent = subject;
    li.onclick = () => showFlashcardsFor(subject);
    ul.appendChild(li);
    addProgressBar(subject);
  }
}
